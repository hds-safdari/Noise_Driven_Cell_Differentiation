clearvars
clc
close all 
 
% insert gene expression by Gillespie
tv = [];
biomass_obj = shoving.biomass();

% Switches
makeVideo = 1;
makePlot  = 1;

% Parameters and initial values
Lx = 2.6e-4; Ly = 2.6e-4; Lz = 10*5.5e-07; % m
Nx = 30;   Ny = 20;   Nz = 1;
dxg = Lx/Nx;         % m, grid size
dyg = Ly/Ny;         % m, grid size
dzg = Lz/Nz;         % m, grid size
gridX = dxg/2:dxg:Lx-dxg/2;
gridY = dyg/2:dyg:Ly-dyg/2;
gridZ = dzg/2:dzg:Lz-dzg/2;

bac_x = Lx/2;
bac_y = Ly/2;
bac_v = 1e-17;        % m3
bac_s = 1;              % start with type 1 (X)
bac_rho = 100;          % kg/m3
bac_m = bac_v*bac_rho;  % kg
bac_r = (3*bac_v/4/pi).^(1/3);
bac_z = bac_r;

gene_ini = 35;            % initial amount of genes
gene_1 = gene_ini;            % initial amount of genes
gene_2 = 2;            
n= 2.0;        %Hill parameter  
beta= 0.15;   %strengths of positive and negative regulatory interactions
gamma= 1/(10*60);   
s= 10;
up=floor(gene_ini+gene_ini*0.25);
lower= 2;
a1    = 1;
a2    = 1;
var_div = 0.05;
ce_num = 1000;  

tend = 7200;       % s
dt   = 10*60;       % s
td   = 20*60;       % s
mum  = log(2)/td;   % 1/s
vmax = 1e-18;       % m^3
K_s   = 0.1;        % mol/m^3
Y_sx = 0.01;        %[mol/g]

%----

figure
% open the video file
if makeVideo
    video_1 = VideoWriter('movie.avi');
    uncompressedVideo = VideoWriter('movie.avi', 'Uncompressed AVI');
    myVideo.FrameRate = 1000;  % Default 30
    myVideo.Quality = 75;    % Default 75
    open(video_1);
end

[X,Y,Z] = meshgrid(gridX,gridY,gridZ);


t = 0; niter = 0;
while t < tend
    nbac = length(bac_x);   % number of cells

       
   % Growth step
    bac_v = (1e-17);
        % Division step 
        for i=1:nbac            % check all cells
            if ( nbac >= 2)
                    [gene_1(i),gene_2(i),step_num] = gene_expression_1(gene_1(i),gene_2(i),up,lower,n,beta,gamma,s,a1,a2);
                    gene_1(i)=BondCkeck(gene_1(i),lower,up); 
                    gene_2(i)=BondCkeck(gene_2(i),lower,up);
            end 
                m_old = bac_m(i);  % store mass before division
                x_old = bac_x(i);   y_old = bac_y(i); z_old = bac_z(i);
                gene_1old=gene_1(i);
                gene_2old=gene_2(i);
                phi = rand*pi;  % random angle for division
                the = rand*pi/2;  % random angle for division
        % % % % % % %% % % % % % %% % % % % % %% % % % % % %
        % % % % % % %% % % % % % %% % % % % % %% % % % % % %
                rand_p1 =  normrnd(0.5,var_div);  
                r3 = abs(rand(1,ce_num));
                r4 = abs(rand(1,ce_num));
        % % % % % % %% % % % % % %% % % % % % %% % % % % % %
                r3 = r3./sum(r3);
                r4 = r4./sum(r4);          
                r3 = gene_1old*r3;
                r4 = gene_2old*r4; 
                r1 =  floor(rand_p1*ce_num);    
                r2 =  floor(rand_p1*ce_num);    
                gene_1(i)=floor(sum(r3(1:r1)));
                gene_2(i)=floor(sum(r4(1:r2)));       
        % % % % % % %% % % % % % %% % % % % % %% % % % % % %
        % % % % % % %% % % % % % %% % % % % % %% % % % % % %
                    % "old" cell
                bac_m(i) =m_old;
                bac_x(i) = x_old + bac_r*cos(phi)*sin(the);
                bac_y(i) = y_old + bac_r*sin(phi)*sin(the);
                if  gene_2(i)>=gene_1(i)
                    bac_s (i) = 2;
                elseif gene_2(i)<gene_1(i)
                    bac_s (i) = 1;
                end
                    % "new" cell
                j = nbac+1;     % index new cell at the end
                bac_m(j) =m_old; 
                bac_x(j) = x_old - bac_r*cos(phi)*sin(the);
                bac_y(j) = y_old - bac_r*sin(phi)*sin(the);
                gene_1(j)= gene_1old-gene_1(i);
                gene_2(j)= gene_2old-gene_2(i);
                gene_1(i)=BondCkeck(gene_1(i),lower,up); 
                gene_2(i)=BondCkeck(gene_2(i),lower,up);     
                gene_1(j)=BondCkeck(gene_1(j),lower,up); 
                gene_2(j)=BondCkeck(gene_2(j),lower,up);
                if  gene_2(j)>=gene_1(j)
                    bac_s (j) = 2;
                elseif gene_2(j)<gene_1(j)
                    bac_s (j) = 1; 
                end    
                nbac = j;   % number of cells
        end 

        % Shoving step (avoiding cell overlap after division)
    tic
    bac_z1 = 5.5e-07*ones(1,nbac);
    bac_r1 = bac_r*ones(1,nbac);
    Results = biomass_obj.pushing3D(nbac, bac_x, bac_y, bac_r1);
    tv=[tv toc];
    bac_x = Results.bac_x;
    bac_y = Results.bac_y;
    bac_z = 5.5e-07*ones(1,nbac);  

    % Time update
    t = t + dt  
    niter = niter+1;
    
    % Plotting
    if makePlot
         clf
        [x,y,z] = sphere;
        for i=1:nbac
            if bac_s(i)==1
                col='r';
            elseif bac_s(i)==2
                col='y';
            end
            surf(x*bac_r+bac_x(i),y*bac_r+bac_y(i),z*bac_r+bac_r,'Facecolor',col,'Edgecolor','none')
            hold on
        end
        box on
        camlight;
        axis equal;
        axis([0 Lx 0 Ly 0 Lz]) ; 
        view(3);
                title(['t =  ',num2str(t),'s'],'FontSize',14)   
    end

    % add frame to video
    if makeVideo, F = getframe;  writeVideo(video_1,F);  end
end
if makeVideo, close(video_1); end