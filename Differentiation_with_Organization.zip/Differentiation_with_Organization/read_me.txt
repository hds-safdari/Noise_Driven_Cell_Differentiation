"Differentiation_organization": The main m.file which produces the main results, FIG.3, and movies. (MATLAB 2016)
The file path should be inserted in the lines:64,213,221, to execute the code. 


"shoving.biomass": JAVA code to evaluate Shoving step. The path of the working folder should be added in this line:
model.modelPath('path');

"gene_expression": MATLAB function to evaluate Gillespie algorithm. 
"clust_coeff" : MATLAB function to stimate clustering coefficient. 
"simple_spectral_partitioning": MATLAB function to estimate community size. 

To run the code, COMSOL 5.2 should be installed. The "COMSOL_Installation_Instructions.pdf" file gives the installation instructions. It requires a license file. The installation would take few minutes. 
"COMSOL Multiphysics" and " LiveLink™ for MATLAB" should be installed from the available packages.


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
THE HINT TO PREVENT FROM ERROR IN JAVA:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

An ERROR often comes from the fact the “javaaddpath” function (we used to point to the shoving java code) actually deletes the paths to COMSOL java routines. 
This can be avoided by using static path definition (instead of this dynamic path definition).

1. In MATLAB command window  write 
       cd(prefdir)

to go to the preferences directory of MATLAB. 
2. Then type also

      edit javaclasspath.txt

and this file will be created because it does not exist yet (probably – but if it exists just append the path as at point 3).  

3. In the new (empty) file “javaclasspath.txt” write this path of the "classes" on your computer:

   Path\ ... \java\shoving\build\classes\

Then save the file.  

4. Close MATLAB and COMSOL server and start again COMSOL with MATLAB.  

5. Now the path to the shoving function will be static and it can be checked by typing:

     javaclasspath('-static')

You should see the path as the last one in the list. 






The code will generate a figure which shows cell population.  

"Organization.jpg" ; a sample figure as the output of the code. 

Data and code associated with:

Safdari et al. Noise-driven Cell Differentiation and the Emergence of Organization. bioRxiv doi: https://doi.org/10.1101/220525
