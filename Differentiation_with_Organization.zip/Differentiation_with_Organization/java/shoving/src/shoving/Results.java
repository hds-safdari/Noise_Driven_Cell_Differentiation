package shoving;

public class Results {
    
    public double[] bac_x;
    public double[] bac_y;   
    public double[] bac_z; 
}
